# FHHGB-Hockey-Dataset > 2025-06-22 11:33pm
https://universe.roboflow.com/dvcss25/fhhgb-hockey-dataset

Provided by a Roboflow user
License: CC BY 4.0

